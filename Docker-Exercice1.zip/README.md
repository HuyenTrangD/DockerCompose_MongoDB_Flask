# Exo docker

Simple app qui permet de tester la création d'image.

On récupère une base de node qui permettra de le lancer.
On crée le Dockerfile.

On build l'image.

On lance l'application.

Poussez votre image sur le docker hub !
